# TensorFlow Breast Cancer example
Uses the real Wisconsin Diagnostic Breast Cancer dataset, or an uploaded CSV with a `label` column.

import argparse, json, os
from pathlib import Path
import pandas as pd
import tensorflow as tf
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=64)
    args = ap.parse_args()

    model_dir = Path(os.getenv("SM_MODEL_DIR", os.getenv("LOCAL_MODEL_DIR", "/tmp/model")))
    model_dir.mkdir(parents=True, exist_ok=True)

    data_dir = os.getenv("SM_CHANNEL_TRAINING") or os.getenv("LOCAL_DATA_DIR")
    csv_path = None
    if data_dir and Path(data_dir).exists():
        files = list(Path(data_dir).glob("*.csv"))
        if files:
            csv_path = files[0]

    if csv_path:
        df = pd.read_csv(csv_path)
        if "label" not in df.columns:
            raise ValueError("Uploaded CSV must contain a 'label' column.")
        X = df.drop(columns=["label"]).values
        y = df["label"].values
        dataset_name = csv_path.name
    else:
        d = load_breast_cancer()
        X, y = d.data, d.target
        dataset_name = "Wisconsin Diagnostic Breast Cancer"

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(X_train.shape[1],)),
        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dense(16, activation="relu"),
        tf.keras.layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    model.fit(X_train, y_train, epochs=args.epochs, batch_size=args.batch_size, verbose=2)
    proba = model.predict(X_test, verbose=0).ravel()

    metrics = {
        "framework":"tensorflow",
        "dataset":dataset_name,
        "roc_auc":float(roc_auc_score(y_test, proba)),
        "train_rows":int(len(X_train)),
        "test_rows":int(len(X_test)),
    }
    print("METRICS", json.dumps(metrics))
    model.save(model_dir/"model.keras")

if __name__ == "__main__":
    main()
